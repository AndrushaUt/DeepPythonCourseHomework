from django.contrib import messages
import pdfkit
from django.shortcuts import render, redirect
from django.http import HttpRequest
from .forms import *
from .models import Resume
from django.contrib.auth.decorators import login_required
from django.forms.models import model_to_dict


def register(request: HttpRequest):
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = UserRegisterForm()
    return render(request, 'authorization/register.html', {'form': form})


def create_resume(request):
    if request.user.username == '':
        return redirect('home')
    if request.method == 'POST':
        form = CreateResumeForm(request.POST, request.FILES)
        if form.is_valid():
            try:
                t1 = Resume(**form.cleaned_data)
                t1.username = request.user.username
                t1.save()
                return redirect('user_page')
            except:
                form.add_error(None, 'Ошибка')
    else:
        form = CreateResumeForm()
    return render(request, 'authorization/create.html', {'form': form})


def user_page(request):
    if request.user.username == '':
        return redirect('home')
    resumes = Resume.objects.filter(username=request.user.username)
    return render(request, 'authorization/user_page.html',
                  {'resumes': resumes})


def view(request, resume_id: int):
    if request.user.username == '':
        return redirect('home')
    resume = Resume.objects.get(username=request.user.username, pk=resume_id)
    return render(request, 'authorization/view.html',
                  {'res': resume, 'resume_id': resume_id})


def edit_resume(request, resume_id: int):
    if request.user.username == '':
        return redirect('home')
    res = Resume.objects.get(username=request.user.username, pk=resume_id)
    if request.method == 'POST':
        form = CreateResumeForm(request.POST, request.FILES)
        if form.is_valid():
            try:
                t1 = Resume(**form.cleaned_data)
                t1.username = request.user.username
                t1.save()
                res.delete()
                return redirect('user_page')
            except:
                form.add_error(None, 'Ошибка')
    else:
        form = CreateResumeForm(model_to_dict(res))
    return render(request, 'authorization/resume.html',
                  {'form': form, 'res': res})


@login_required
def main_create(request: HttpRequest):
    return render(request, 'authorization/user_page.html')

# request.session
# redirect(url, arg)
# def view(request, pk=None) ?
