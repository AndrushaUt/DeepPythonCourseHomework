from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm


class CreateResumeForm(forms.Form):
    title = forms.CharField(label="Title", max_length=100,
                            widget=forms.TextInput(
                                attrs={"class": "form-control",
                                       "placeholder": "Title"}))
    fullname = forms.CharField(max_length=100, widget=forms.TextInput(
        attrs={"class": "form-control", "placeholder": "Fullname"}),required=False)
    photo = forms.ImageField(required=False)
    birthday = forms.DateField(widget=forms.DateInput(
        attrs={"class": "form-control", "placeholder": "Birthday"}),required=False)
    email = forms.EmailField(widget=forms.EmailInput(
        attrs={"class": "form-control", "placeholder": "Email"}),required=False)
    phone_number = forms.IntegerField(widget=forms.TextInput(
        attrs={"class": "form-control", "placeholder": "Telephone"}),required=False)
    education = forms.CharField(widget=forms.Textarea(
        attrs={"class": "form-control", "placeholder": "Education"}),required=False)
    courses = forms.CharField(widget=forms.Textarea(
        attrs={"class": "form-control", "placeholder": "Courses"}),required=False)
    skills = forms.CharField(widget=forms.Textarea(
        attrs={"class": "form-control", "placeholder": "Skills"}),required=False)
    qualities = forms.CharField(widget=forms.Textarea(
        attrs={"class": "form-control", "placeholder": "Qualities"}),required=False)


class UserRegisterForm(UserCreationForm):
    username = forms.CharField(label='Login', widget=forms.TextInput(
        attrs={"class": "form-control", "placeholder": "Login"}))
    password1 = forms.CharField(label='Password', widget=forms.PasswordInput(
        attrs={"class": "form-control", "placeholder": "Password"}))
    password2 = forms.CharField(label='Password2', widget=forms.PasswordInput(
        attrs={"class": "form-control", "placeholder": "Repeat password"}))

    class Meta:
        model = User
        fields = {'username', 'password1', 'password2'}


class UserLoginForm(AuthenticationForm):
    username = forms.CharField(label='Login', widget=forms.TextInput(
        attrs={"class": "form-control", "placeholder": "Login"}))
    password = forms.CharField(label='Password', widget=forms.PasswordInput(
        attrs={"class": "form-control", "placeholder": "Password"}))

    class Meta:
        model = User
        fields = {'username', 'password'}
