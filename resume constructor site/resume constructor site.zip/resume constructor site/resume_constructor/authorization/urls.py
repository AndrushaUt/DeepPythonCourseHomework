from django.urls import path
from .views import *
from django.contrib.auth import views as auth_views
from django.conf.urls.static import static
from django.conf import settings

urlpatterns = [
    path('main/', user_page, name='user_page'),
    path('edit/<int:resume_id>/', edit_resume, name="edit_resume"),
    path('creation/', create_resume, name="create_form"),
    path('register/', register, name='register'),
    path('logout/', auth_views.LogoutView.as_view(template_name='authorization/login.html'), name='logout'),
    path('', auth_views.LoginView.as_view(template_name='authorization/login.html', form_class=UserLoginForm), name='home'),
    path('view/<int:resume_id>/', view, name="view")
]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root = settings.MEDIA_ROOT)