from django.db import models


class Resume(models.Model):
    title = models.CharField(max_length=100)
    fullname = models.CharField(max_length=100, null=True)
    photo = models.ImageField(null=True, upload_to="photos/", blank=True)
    birthday = models.DateField(null=True)
    email = models.EmailField(null=True)
    phone_number = models.IntegerField(null=True)
    education = models.TextField(null=True)
    courses = models.TextField(null=True)
    skills = models.TextField(null=True)
    qualities = models.TextField(null=True)
    username = models.CharField(max_length=100, null=True)
